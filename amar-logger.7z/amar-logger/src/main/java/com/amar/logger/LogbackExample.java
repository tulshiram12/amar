package com.amar.logger;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogbackExample {
    
	
	public static void main( String[] args ) {
	    Logger logger = LoggerFactory.getLogger(LogbackExample.class);
	    int i =10;
	    if(i<15) {
	    	logger.info("i is less than 10");
	    }else {
	    	logger.info("i is greter than 10");
	    }
	    if(i<16) {
	    	logger.info("i is less than 16");
	    	//this will not print as loger level is set to info
	    	logger.debug("i is less than 10");
	    }
	   
    }
    
}
